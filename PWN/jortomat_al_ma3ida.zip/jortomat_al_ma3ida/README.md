 #  jortomat_al_ma3ida (simple stack buffer overflow)

## Discription

You are a chef at a busy restaurant, and one of your customers, Mr. Ahmed, has a sensitive stomach due to a stomach ulcer (jortomat al ma3ida). 
He specifically warned you:"Please, don't give me too much food at once! My stomach can't handle it. If you overload my plate, it will cause me pain and ruin my meal!"


## :white_check_mark: FLAG:  Easy



