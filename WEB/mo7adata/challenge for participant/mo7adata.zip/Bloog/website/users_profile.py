from flask import Blueprint, render_template, request, flash, jsonify, abort, redirect, url_for, render_template_string
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
import json
from .models import Post
from . import db
from .models import User
from datetime import datetime
from jinja2 import Template
import os

users_profile = Blueprint('users_profile', __name__)


template_profile = os.path.join(os.path.dirname(__file__), '.', 'templates', 'profile.html')

@users_profile.route(f'/users/<int:id>')
@login_required
def index(id):
    user = User.query.filter_by(id=id).first()
    if not user:
        flash("User not found")
        return redirect(url_for('home.index'))
    
    posts = user.posts


    for post in posts:
        try:

            theme_template = Template(post.theme)
            post.theme = theme_template.render()
        except Exception as e:

            post.theme = post.theme

    with open(template_profile
, 'r') as file:
        template = file.read()
    

    return render_template_string(template, user=current_user, posts=posts, user_profile=user)