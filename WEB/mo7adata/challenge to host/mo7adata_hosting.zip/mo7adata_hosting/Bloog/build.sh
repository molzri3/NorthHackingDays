#!/bin/bash

# Build the Podman/Docker image
podman build -t bloog-app .

# Run the Podman/Docker container
podman run -d -p 5000:5000 --name bloog-container bloog-app

# Print the container status
podman ps -a | grep bloog-container